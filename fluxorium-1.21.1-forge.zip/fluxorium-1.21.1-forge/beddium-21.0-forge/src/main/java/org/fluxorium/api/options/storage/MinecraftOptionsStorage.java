package org.fluxorium.api.options.storage;

import org.fluxorium.impl.Fluxorium;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import org.fluxorium.api.options.structure.OptionStorage;

public class MinecraftOptionsStorage implements OptionStorage<Options> {
    public static final MinecraftOptionsStorage INSTANCE = new MinecraftOptionsStorage();

    private final Minecraft client;

    private MinecraftOptionsStorage() {
        this.client = Minecraft.getInstance();
    }

    @Override
    public Options getData() {
        return this.client.options;
    }

    @Override
    public void save() {
        this.getData().save();

        Fluxorium.logger().info("Flushed changes to Minecraft configuration");
    }
}
