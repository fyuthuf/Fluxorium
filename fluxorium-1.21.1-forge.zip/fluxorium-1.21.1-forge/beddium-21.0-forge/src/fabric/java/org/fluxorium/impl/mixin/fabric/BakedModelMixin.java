package org.fluxorium.impl.mixin.fabric;

import net.minecraft.client.resources.model.BakedModel;
import org.fluxorium.fabric.injectors.BakedModelInjector;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BakedModel.class)
public interface BakedModelMixin extends BakedModelInjector {
}
