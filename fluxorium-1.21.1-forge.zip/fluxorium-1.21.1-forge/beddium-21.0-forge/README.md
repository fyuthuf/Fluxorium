<img src="src/main/resources/icon.png" width="128">



Fluxorium is an open-source Minecraft client performance mod for Minecraft Forge 1.21.1. It is a fork of Beddium, which is based on Embeddium and incorporates work from Sodium.



Fluxorium aims to continue this work under its own project identity while preserving credit to the original developers and contributors.



Notice



Fluxorium is an unofficial fork of Beddium, which is itself an unofficial fork of Embeddium. It targets Minecraft Forge, not NeoForge. The upstream project this repository is derived from is Beddium: https://github.com/basdxz/beddium (Forge 1.21.x code lives in the `21.0/forge` branch, https://github.com/basdxz/beddium/tree/21.0/forge).



Please do not report Fluxorium-specific issues to the maintainers of Beddium, Embeddium, or Sodium. Before reporting an issue, make sure it can be reproduced with Fluxorium and provide the relevant logs.



Highlights



Fluxorium inherits the rendering and optimization work present in its upstream codebase, including:



- An optimized terrain rendering system.

- Performance improvements to the rendering pipeline used by entities, GUIs, and block entities.

- Various rendering optimizations originating from Sodium and Embeddium.

- Integrated Fabric Rendering API support inherited from the upstream project.

- Additional APIs intended to support mod integration.

- Optional translucency sorting, configurable through Video Settings, if supported by this build.

- Compatibility fixes and patches inherited from the upstream project.



The exact feature set and compatibility depend on the code included in this version of Fluxorium.



Compatibility



- Minecraft: 1.21.1

- Mod loader: Minecraft Forge

- Project version: 1.0.0

- Environment: Client-side



Fluxorium is intended for the Forge mod loader. It is not a NeoForge build.



Compatibility with other mods depends on their versions and the APIs they use. Conflicts may occur with other rendering or optimization mods that modify the same systems.



Installation



1. Install Minecraft Forge for Minecraft 1.21.1.

2. Download a compatible Fluxorium release when one is available.

3. Place the Fluxorium JAR file in your Minecraft instance's `mods` directory.

4. Launch Minecraft using the Forge profile.



Do not install multiple conflicting terrain renderers in the same instance.



Building from Source



Fluxorium uses Gradle to build its source code.



Requirements:



- A compatible JDK, as required by the project configuration.

- The Gradle wrapper included in the repository.

- An internet connection to download the required dependencies.



On Windows, run:



```bat
gradlew.bat build
```





On Linux or macOS, run:



```bash
./gradlew build
```





The build output is generated according to the project's Gradle configuration.



Credits



Fluxorium maintainer



- Fyuthuf - Fluxorium fork and project maintenance.



Upstream repositories



- Beddium (the upstream project this fork is based on): https://github.com/basdxz/beddium

- Beddium Forge 1.21.x branch: https://github.com/basdxz/beddium/tree/21.0/forge

- Embeddium (the upstream project Beddium is based on): https://github.com/embeddedt/embeddium



Upstream projects and contributors



- The Beddium developers - for the project Fluxorium is forked from.

- Embeddedt - for creating and maintaining Embeddium.

- JellySquid and the CaffeineMC team - for creating Sodium and its rendering improvements.

- Asek3 - for the initial Forge port.

- XFactHD - for compatibility issue research and early testing.

- Pepper - for assistance with Forge lighting support.

- Houstonruss - for the original logo.



Fluxorium builds upon the work of these developers and the broader Minecraft modding community. Their original contributions remain credited to them.



## License



Beddium is licensed under the GNU Lesser General Public License version 3 (LGPL-3.0). Portions of the option screen code are based on Reese's Sodium Options by FlashyReese and are used under the MIT License.



Fluxorium is derived from upstream projects and must retain the applicable license terms, copyright notices, and attribution requirements.



See the repository's license files, including `COPYING`, `COPYING.LESSER`, and `src/main/resources/licenses/rso.txt`, for the applicable license texts. Do not remove or replace these files when redistributing the project.



Disclaimer



Fluxorium is an independent community project. It is not an official release of Minecraft, Mojang Studios, Microsoft, Sodium, Embeddium, or Beddium.



All original work remains credited to its respective authors and contributors.

