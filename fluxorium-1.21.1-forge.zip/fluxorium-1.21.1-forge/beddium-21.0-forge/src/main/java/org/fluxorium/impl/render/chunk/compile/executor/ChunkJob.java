package org.fluxorium.impl.render.chunk.compile.executor;

import org.fluxorium.impl.render.chunk.compile.ChunkBuildContext;
import org.fluxorium.impl.util.task.CancellationToken;

public interface ChunkJob extends CancellationToken {
    void execute(ChunkBuildContext context);

    boolean isStarted();
}
