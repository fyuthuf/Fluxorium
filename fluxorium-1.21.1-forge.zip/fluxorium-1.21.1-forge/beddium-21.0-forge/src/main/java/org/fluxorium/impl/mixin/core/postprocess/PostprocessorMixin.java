package org.fluxorium.impl.mixin.core.postprocess;

import org.fluxorium.impl.world.WorldSlice;
import org.fluxorium.impl.world.cloned.ClonedChunkSection;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = { WorldSlice.class, ClonedChunkSection.class }, remap = false)
public class PostprocessorMixin {
}
