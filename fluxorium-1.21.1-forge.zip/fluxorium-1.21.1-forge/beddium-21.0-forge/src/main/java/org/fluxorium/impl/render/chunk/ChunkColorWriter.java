package org.fluxorium.impl.render.chunk;

import org.fluxorium.api.util.ColorABGR;
import org.fluxorium.api.util.ColorMixer;
import org.fluxorium.impl.render.ShaderModBridge;

public interface ChunkColorWriter {
    int writeColor(int colorWithAlpha, float aoValue);

    ChunkColorWriter LEGACY = ColorABGR::withAlpha;
    ChunkColorWriter EMBEDDIUM = (color, ao) -> ColorMixer.mulSingleWithoutAlpha(color, (int)(ao * 255));

    static ChunkColorWriter get() {
        return ShaderModBridge.emulateLegacyColorBrightnessFormat() ? LEGACY : EMBEDDIUM;
    }
}
