package org.fluxorium.api.options.structure;

public interface OptionStorage<T> {
    T getData();

    void save();
}
