package org.fluxorium.impl.render.chunk.shader;

import org.fluxorium.impl.gl.shader.uniform.GlUniform;
import org.fluxorium.impl.gl.shader.uniform.GlUniformBlock;

import java.util.function.IntFunction;

public interface ShaderBindingContext {
    <U extends GlUniform<?>> U bindUniform(String name, IntFunction<U> factory);

    GlUniformBlock bindUniformBlock(String name, int bindingPoint);
}
