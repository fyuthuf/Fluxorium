@ApiStatus.Internal
package org.fluxorium.api.internal;

import org.jetbrains.annotations.ApiStatus;