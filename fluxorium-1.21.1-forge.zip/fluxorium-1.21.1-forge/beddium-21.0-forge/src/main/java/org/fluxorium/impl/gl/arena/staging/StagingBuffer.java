package org.fluxorium.impl.gl.arena.staging;

import org.fluxorium.impl.gl.buffer.GlBuffer;
import org.fluxorium.impl.gl.device.CommandList;

import java.nio.ByteBuffer;

public interface StagingBuffer {
    void enqueueCopy(CommandList commandList, ByteBuffer data, GlBuffer dst, long writeOffset);

    void flush(CommandList commandList);

    void delete(CommandList commandList);

    void flip();
}
