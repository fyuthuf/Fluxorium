package org.fluxorium.impl.model.light;

public enum LightMode {
    SMOOTH,
    FLAT
}
