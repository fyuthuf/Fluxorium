package org.fluxorium.impl.model;

import org.fluxorium.impl.render.immediate.model.ModelCuboid;
import org.jetbrains.annotations.Nullable;

public interface ModelCuboidAccessor {
    ModelCuboid sodium$copy();

    @Nullable
    ModelCuboid embeddium$getSimpleCuboid();
}
