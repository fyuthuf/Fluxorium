package org.fluxorium.impl.gl.util;

public record VertexRange(int vertexStart, int vertexCount) {
}
