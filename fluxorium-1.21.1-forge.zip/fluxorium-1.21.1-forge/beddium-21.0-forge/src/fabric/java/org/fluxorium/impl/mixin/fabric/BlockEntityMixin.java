package org.fluxorium.impl.mixin.fabric;

import net.minecraft.world.level.block.entity.BlockEntity;
import org.fluxorium.fabric.injectors.BlockEntityInjector;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockEntity.class)
public class BlockEntityMixin implements BlockEntityInjector {
}
