package org.fluxorium.impl.compatibility.environment.probe;

public record GraphicsAdapterInfo(GraphicsAdapterVendor vendor, String name, String version) {

}
