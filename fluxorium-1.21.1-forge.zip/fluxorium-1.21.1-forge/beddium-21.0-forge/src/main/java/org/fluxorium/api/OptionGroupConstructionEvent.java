package org.fluxorium.api;

import org.fluxorium.api.options.structure.Option;
import org.fluxorium.api.eventbus.FluxoriumEvent;
import org.fluxorium.api.eventbus.EventHandlerRegistrar;
import org.fluxorium.api.options.OptionIdentifier;

import java.util.List;

/**
 * Fired when an option group is created, to allow replacing options in that group if desired. (Can be used,
 * for instance, to extend the VSync or fullscreen options.)
 */
public class OptionGroupConstructionEvent extends FluxoriumEvent {
    public static final EventHandlerRegistrar<OptionGroupConstructionEvent> BUS = new EventHandlerRegistrar<>();

    private final OptionIdentifier<Void> id;
    private final List<Option<?>> options;

    public OptionGroupConstructionEvent(OptionIdentifier<Void> id, List<Option<?>> options) {
        this.id = id;
        this.options = options;
    }

    public List<Option<?>> getOptions() {
        return this.options;
    }

    public OptionIdentifier<Void> getId() {
        return this.id;
    }
}
