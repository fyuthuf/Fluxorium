package org.fluxorium.impl.model.quad;

import org.fluxorium.impl.model.quad.properties.ModelQuadFacing;

public interface BakedQuadView extends ModelQuadView {
    ModelQuadFacing getNormalFace();
    
    boolean hasShade();

    void setFlags(int flags);
}
