package org.fluxorium.api;

import org.fluxorium.api.eventbus.FluxoriumEvent;
import org.fluxorium.api.eventbus.EventHandlerRegistrar;
import org.fluxorium.api.render.chunk.SectionInfoBuilder;

/**
 * This event is fired to allow some control over the chunk render data before it is finalized.
 */
public class ChunkDataBuiltEvent extends FluxoriumEvent {
    public static final EventHandlerRegistrar<ChunkDataBuiltEvent> BUS = new EventHandlerRegistrar<>();
    private final SectionInfoBuilder dataBuilder;

    public ChunkDataBuiltEvent(SectionInfoBuilder dataBuilder) {
        this.dataBuilder = dataBuilder;
    }

    public SectionInfoBuilder getDataBuilder() {
        return this.dataBuilder;
    }
}
