package org.fluxorium.impl.platform.windows.api.version;

public record QueryResult(long address, int length) {
}
