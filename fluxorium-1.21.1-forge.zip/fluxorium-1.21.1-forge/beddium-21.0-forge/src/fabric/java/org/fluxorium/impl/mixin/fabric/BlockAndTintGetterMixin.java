package org.fluxorium.impl.mixin.fabric;

import net.minecraft.world.level.BlockAndTintGetter;
import org.fluxorium.fabric.injectors.BlockAndTintGetterInjector;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockAndTintGetter.class)
public interface BlockAndTintGetterMixin extends BlockAndTintGetterInjector {
}
