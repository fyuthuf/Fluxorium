package org.fluxorium.impl.mixin.fabric;

import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import org.fluxorium.fabric.injectors.BlockEntityRendererInjector;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockEntityRenderer.class)
public interface BlockEntityRendererMixin extends BlockEntityRendererInjector {
}
