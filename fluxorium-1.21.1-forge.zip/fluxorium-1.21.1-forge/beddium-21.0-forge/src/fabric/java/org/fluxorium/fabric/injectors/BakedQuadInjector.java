package org.fluxorium.fabric.injectors;

public interface BakedQuadInjector {
    default boolean hasAmbientOcclusion() {
        return true;
    }
}
