package org.fluxorium.api.options.structure;

public enum OptionFlag {
    REQUIRES_RENDERER_RELOAD,
    REQUIRES_RENDERER_UPDATE,
    REQUIRES_ASSET_RELOAD,
    REQUIRES_GAME_RESTART
}
