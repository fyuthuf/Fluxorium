package org.fluxorium.impl.render.texture;

public interface SpriteContentsExtended {
    void sodium$setActive(boolean value);
    boolean sodium$isActive();

    boolean sodium$hasAnimation();
}
