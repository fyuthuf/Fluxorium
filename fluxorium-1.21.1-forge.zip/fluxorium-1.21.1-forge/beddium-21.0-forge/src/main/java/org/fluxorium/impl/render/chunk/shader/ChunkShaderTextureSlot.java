package org.fluxorium.impl.render.chunk.shader;

public enum ChunkShaderTextureSlot {
    BLOCK,
    LIGHT;

    public static final ChunkShaderTextureSlot[] VALUES = ChunkShaderTextureSlot.values();
}
