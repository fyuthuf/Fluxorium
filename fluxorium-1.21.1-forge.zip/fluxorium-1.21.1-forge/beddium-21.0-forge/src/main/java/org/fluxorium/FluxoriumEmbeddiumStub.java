package org.fluxorium;

import net.minecraftforge.fml.common.Mod;

@Mod("embeddium")
public class FluxoriumEmbeddiumStub {
}
