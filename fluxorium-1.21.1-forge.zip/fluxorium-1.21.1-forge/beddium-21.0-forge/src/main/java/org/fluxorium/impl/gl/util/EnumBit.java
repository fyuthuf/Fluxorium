package org.fluxorium.impl.gl.util;

public interface EnumBit {
    int getBits();
}
