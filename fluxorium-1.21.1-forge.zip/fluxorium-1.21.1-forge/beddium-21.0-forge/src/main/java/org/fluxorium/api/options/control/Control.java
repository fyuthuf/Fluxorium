package org.fluxorium.api.options.control;

import org.fluxorium.api.options.structure.Option;
import org.fluxorium.api.options.structure.OptionControlElement;
import org.fluxorium.api.math.Dim2i;

public interface Control<T> {
    Option<T> getOption();

    OptionControlElement<T> createElement(Dim2i dim);

    int getMaxWidth();
}
