package org.fluxorium.impl.mixin.fabric;

import net.minecraft.client.renderer.block.model.BakedQuad;
import org.fluxorium.fabric.injectors.BakedQuadInjector;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = BakedQuad.class, priority = 100)
public class BakedQuadMixin implements BakedQuadInjector {
    private final boolean hasAmbientOcclusion = true;
}
