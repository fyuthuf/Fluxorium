package org.fluxorium.impl;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLLoader;
import org.fluxorium.impl.compatibility.checks.EarlyDriverScanner;
import org.fluxorium.impl.compatibility.environment.probe.GraphicsAdapterProbe;
import org.fluxorium.impl.compatibility.workarounds.Workarounds;

public class FluxoriumPreLaunch {
    public static void onPreLaunch() {
        if(FMLLoader.getDist() == Dist.CLIENT) {
            GraphicsAdapterProbe.findAdapters();
            EarlyDriverScanner.scanDrivers();
            Workarounds.init();
        }
    }
}