package org.fluxorium.impl.mixin.fabric;

import net.minecraft.world.level.material.Fluid;
import org.fluxorium.fabric.injectors.FluidInjector;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Fluid.class)
public class FluidMixin implements FluidInjector {
}
