package org.fluxorium.impl.gui.options.storage;

import org.fluxorium.impl.Fluxorium;
import org.fluxorium.api.options.structure.OptionStorage;
import org.fluxorium.impl.gui.FluxoriumOptions;

import java.io.IOException;

public class FluxoriumOptionsStorage implements OptionStorage<FluxoriumOptions> {
    private final FluxoriumOptions options;

    public FluxoriumOptionsStorage() {
        this.options = Fluxorium.options();
    }

    @Override
    public FluxoriumOptions getData() {
        return this.options;
    }

    @Override
    public void save() {
        try {
            FluxoriumOptions.writeToDisk(this.options);
        } catch (IOException e) {
            throw new RuntimeException("Couldn't save configuration changes", e);
        }

        Fluxorium.logger().info("Flushed changes to Fluxorium configuration");
    }
}
