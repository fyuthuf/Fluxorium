package org.fluxorium.impl.mixin.fabric;

import net.minecraft.world.phys.AABB;
import org.fluxorium.fabric.injectors.AABBInjector;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(AABB.class)
public class AABBMixin implements AABBInjector {
}
