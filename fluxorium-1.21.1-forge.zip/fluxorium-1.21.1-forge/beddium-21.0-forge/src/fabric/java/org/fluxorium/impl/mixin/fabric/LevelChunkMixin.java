package org.fluxorium.impl.mixin.fabric;

import net.minecraft.world.level.chunk.LevelChunk;
import org.fluxorium.fabric.injectors.LevelChunkInjector;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(LevelChunk.class)
public class LevelChunkMixin implements LevelChunkInjector {
}
