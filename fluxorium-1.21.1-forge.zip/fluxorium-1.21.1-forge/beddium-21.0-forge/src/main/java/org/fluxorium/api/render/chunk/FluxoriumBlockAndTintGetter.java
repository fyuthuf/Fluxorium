package org.fluxorium.api.render.chunk;

import net.minecraft.world.level.BlockAndTintGetter;

public interface FluxoriumBlockAndTintGetter extends BlockAndTintGetter {
}
