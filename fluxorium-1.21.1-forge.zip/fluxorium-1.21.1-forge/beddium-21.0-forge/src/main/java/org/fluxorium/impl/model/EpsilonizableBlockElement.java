package org.fluxorium.impl.model;

public interface EpsilonizableBlockElement {
    void embeddium$epsilonize();
}
