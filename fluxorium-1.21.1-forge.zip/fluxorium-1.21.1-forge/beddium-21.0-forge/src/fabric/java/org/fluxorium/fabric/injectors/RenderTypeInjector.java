package org.fluxorium.fabric.injectors;

public interface RenderTypeInjector {
    default int getChunkLayerId() {
        throw new AssertionError();
    }
}
