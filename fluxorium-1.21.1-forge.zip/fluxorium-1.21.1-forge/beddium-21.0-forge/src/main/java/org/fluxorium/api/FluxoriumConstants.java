package org.fluxorium.api;

public class FluxoriumConstants {
    public static final String MODID = "fluxorium";
    public static final String MODNAME = "Fluxorium";
}
