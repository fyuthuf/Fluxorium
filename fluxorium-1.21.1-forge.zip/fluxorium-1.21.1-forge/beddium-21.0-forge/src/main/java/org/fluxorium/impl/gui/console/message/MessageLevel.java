package org.fluxorium.impl.gui.console.message;

public enum MessageLevel {
    INFO,
    WARN,
    SEVERE
}
